/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package registrationlogin;

import java.util.Scanner;

/**
 *
 * @author Vutlhari
 */
public class RegistrationLogin {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login obj = new Login();
        //declaration
        String username;
        String password;
        String cellPhoneNumber;

        //user registration
        System.out.println("Registration");
        System.out.println("Enter your first name:");
        String firstName = input.nextLine();

        System.out.println("Enter your last name:");
        String lastName = input.nextLine();
        
        //loop validating the username
        while (true) {
            System.out.println("Enter a username (must contain an underscore) and be no more than 5 characters");
            username = input.nextLine();

            if (obj.checkUserName(username)) {
                System.out.println("Username successfully captured.");
                break;
            } else {
                System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
            }
        }
         //loop validating the password
        while (true) {
            System.out.println("Enter a password (at least 8 characters; a capital letter, a number and a special character)");
            password = input.nextLine();

            if (obj.checkPasswordComplexity(password)) {
                System.out.println("Password successfully captured");
                break;
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number and a special character.");
            }
        }
         //loop validating the cellphone number
        while (true) {
            System.out.println("Enter your cell phone number (with international code, e.g. +27838968976)");
            cellPhoneNumber = input.nextLine();

            if (obj.checkCellPhoneNumber(cellPhoneNumber)) {
                System.out.println("Cell phone number successfully added.");
                break;
            } else {
                System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
            }
        }

        //register validation
        String registrationMessage = obj.registerUser(username, password, cellPhoneNumber, firstName, lastName);
        System.out.println(registrationMessage);

        //login feature
        if (registrationMessage.equals("Username successfully captured.")) {
            System.out.println();
            System.out.println("Login");

            System.out.print("Enter your username: ");
            String strLoginUsername = input.nextLine();

            System.out.print("Enter your password: ");
            String strLoginPassword = input.nextLine();

            boolean blnSuccess = obj.loginUser(strLoginUsername, strLoginPassword);
            System.out.println(obj.returnLoginStatus(blnSuccess));
        }
        input.close();
    }

}