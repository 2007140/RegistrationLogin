package registrationlogin;

import java.util.regex.Pattern;

/**
 *
 * @author Vutlhari
 */
public class Login {

    // Store the user's information
    private String firstName;
    private String lastName;
    private String userName;
    private String password;
    private String cellPhoneNumber;

    // Store the login result
    private boolean loginSuccessful;

    // Empty constructor
    public Login() {
        loginSuccessful = false;
    }

    // Check if the username is correctly formatted
    // Parameter: userName
    public boolean checkUserName(String userName) {

        if (userName == null) {
            return false;
        }

        if (userName.contains("_") && userName.length() <= 5) {
            return true;
        }

        return false;
    }

    // Check if the password meets the required complexity
    // Parameter: password
    public boolean checkPasswordComplexity(String password) {

        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasCapitalLetter = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;

        // Check each character in the password
        for (int i = 0; i < password.length(); i++) {

            char character = password.charAt(i);

            // Check for a capital letter
            if (Character.isUpperCase(character)) {
                hasCapitalLetter = true;
            }

            // Check for a number
            if (Character.isDigit(character)) {
                hasNumber = true;
            }

            // Check for a special character
            if (!Character.isLetterOrDigit(character)) {
                hasSpecialCharacter = true;
            }
        }

        // Password is correct if all requirements are met
        return hasCapitalLetter && hasNumber && hasSpecialCharacter;
    }

    // Check if the cellphone number is correctly formatted
    
    public boolean checkCellPhoneNumber(String cellPhoneNumber) {

        if (cellPhoneNumber == null) {
            return false;
        }

        // Regular expression for a South African cellphone number
        // Source: Oracle Java Documentation 
        String regex = "\\+27[0-9]{9}$";

        return Pattern.matches(regex, cellPhoneNumber);
    }

    // Register the user
    // Add parameters inside the method
    public String registerUser(String userName, String password,
            String cellPhoneNumber, String firstName, String lastName) {

        // Store the user's details
        this.userName = userName;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
        this.firstName = firstName;
        this.lastName = lastName;

        // Check the username
        if (!checkUserName(userName)) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        // Check the password
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }

        // Check the cellphone number
        if (!checkCellPhoneNumber(cellPhoneNumber)) {
            return "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
        }

        return "User is registered successfully";
    }

    // Check if the entered username and password match the registered details
    //add parameters inside the method
    
    public boolean loginUser(String enteredUserName, String enteredPassword) {

        if (userName != null && password != null
                && userName.equals(enteredUserName)
                && password.equals(enteredPassword)) {

            loginSuccessful = true;

        } else {

            loginSuccessful = false;
        }

        return loginSuccessful;
    }

    // Return the login status message, parameter also included inside the method
 
    public String returnLoginStatus(boolean loginSuccessful) {

        if (loginSuccessful) {
            return "Welcome " + firstName + ", " + lastName
                    + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}